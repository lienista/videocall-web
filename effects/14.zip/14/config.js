var effectData = {
    framePos: {
        x: 0.2,
        y: 0.8,
    },
    frameScale: 2
};

var state = 0; //0 = narrator, 1 = man

function Effect() {
    var self = this;

    this.init = function() {
        Api.meshfxMsg("spawn", 104, 0, "!glfx_FACE");
        Api.meshfxMsg("spawn", 4, 0, "background.bsm2");
        Api.meshfxMsg("shaderVec4", 6, 0, effectData.framePos.x + " " + effectData.framePos.y + " " + effectData.frameScale + " 0");   
        Api.showRecordButton();
    };

    this.restart = function() {
        Api.meshfxReset();
        self.init();
    };

    this.faceActions = [];
    this.noFaceActions = [];

    this.videoRecordStartActions = [];
    this.videoRecordFinishActions = [];
    this.videoRecordDiscardActions = [this.restart];
}

configure(new Effect());