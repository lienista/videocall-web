var effectData = {
    framePos: {
        x: -0.05,
        y: -0.5,
    },
    frameScale: 2
};

var state = 0; //0 = narrator, 1 = baby wrens
const settings = {
    global: {
        headRotSens: 1.2,
    }
}

function Effect() {
    var self = this;

    this.update = function () { 
        const rotation = getHeadRotation();
        if(rotation === -1) {
            setPinkWrenMask();
        } else if(rotation === 1) {
            setNarratorMask();
        }
    }

    this.init = function() {
        Api.meshfxMsg("spawn", 5, 0, "!glfx_FACE");
        Api.meshfxMsg("spawn", 4, 0, "background.bsm2");

        Api.meshfxMsg("shaderVec4", 6, 0, effectData.framePos.x + " " + effectData.framePos.y + " " + effectData.frameScale + " 0");   
        Api.showRecordButton();
    };

    this.restart = function() {
        Api.meshfxReset();
        self.init();
    };

    this.faceActions = [self.update];
    this.noFaceActions = [];

    this.videoRecordStartActions = [];
    this.videoRecordFinishActions = [];
    this.videoRecordDiscardActions = [this.restart];
}

configure(new Effect());

function setPinkWrenMask() {
    removeMask();
    Api.meshfxMsg("spawn", 0, 0, "bird_g.bsm2");
    state = 1;
}

function removeMask() {
    if(state===1) {
        Api.meshfxMsg("del", 0);
    }
    state = 0;
}

function setNarratorMask() {
    removeMask();
}

function getHeadRotation() {
    const mv = Api.modelview();
    const rot = (-mv[2]) * settings.global.headRotSens;

    if (rot <= -0.33333) return -1;     // left
	if (rot <= 0.33333) return 0;       // center
	else return 1;                      // right
}