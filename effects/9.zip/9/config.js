var state = 0; //0 = narrator, 1 = bear, 2 = wolf
const settings = {
    global: {
        headRotSens: 1.2,
    }
}

function Effect() {
    var self = this;

    this.update = function () { 
        const rotation = getHeadRotation();
        if(rotation === -1 && isSmile()) {
            setWrenMask();
        } else if(rotation === -1 && isMouthOpen()) {
            setFoxMask();
        } else if(rotation === 1) {
            setNarratorMask();
        } 
    }

    this.init = function() {
        Api.meshfxMsg("spawn", 104, 0, "!glfx_FACE");
        Api.meshfxMsg("spawn", 3, 0, "quad.bsm2");
        self.faceActions = [self.update];
        
        Api.showRecordButton();
    };

    this.restart = function() {
        Api.meshfxReset();
        self.init();
    };

    this.faceActions = [];
    this.noFaceActions = [];

    this.videoRecordStartActions = [];
    this.videoRecordFinishActions = [];
    this.videoRecordDiscardActions = [this.restart];
}

configure(new Effect());

function setWrenMask() {
    removeMask();
    Api.meshfxMsg("spawn", 0, 0, "bird.bsm2");
    state = 1;
}

function setFoxMask() {
    removeMask();
    Api.meshfxMsg("spawn", 0, 0, "fox.bsm2");
    state = 2;
}

function removeMask() {
    if(state===1 || state ===2) {
        Api.meshfxMsg("del", 0);
    }
    state = 0;
}

function setNarratorMask() {
    removeMask();
}

function getHeadRotation() {
    const mv = Api.modelview();
    const rot = (-mv[2]) * settings.global.headRotSens;

    if (rot <= -0.33333) return -1;     // left
	if (rot <= 0.33333) return 0;       // center
	else return 1;                      // right
}