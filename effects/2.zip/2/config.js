var effectData = {
    framePos: {
        x: -0.4,
        y: 0.7,
    },
    frameScale: 0.8
};

var state = 0; //0 = narrator, 1 = bear, 2 = wolf
const settings = {
    global: {
        headRotSens: 1.2,
    }
}

function Effect() {
    var self = this;

    this.meshes = [
        {   
            file: "bear_face.bsm2", 
            anims: [
                { 
                    a: "static", 
                    t: 0 
                },
            ],
            is_physics_applied: Boolean("False".toLowerCase())
        },
        { 
            file: "bear_hair.bsm2", 
            anims: [
                { 
                    a: "static", 
                    t: 0 
                },
            ],
            is_physics_applied: Boolean("False".toLowerCase())
        },
        { 
            file: "bear_nose.bsm2", 
            anims: [
                { a: "static", t: 0 },
            ],
            is_physics_applied: Boolean("False".toLowerCase())
        },
    ];

    this.update = function () { 
        const rotation = getHeadRotation();
        if(rotation === -1 && isSmile()) {
            setBearMask();
        } else if(rotation === -1 && isMouthOpen()) {
            setWolfMask();
        } else if(rotation === 1) {
            setNarratorMask();
        }
    }

    this.init = function() {
        Api.meshfxMsg("spawn", 5, 0, "!glfx_FACE");
        Api.meshfxMsg("spawn", 4, 0, "quad.bsm2");
        Api.showRecordButton();
    };

    this.restart = function() {
        Api.meshfxReset();
        self.init();
    };

    this.faceActions = [this.update];
    this.noFaceActions = [];

    this.videoRecordStartActions = [];
    this.videoRecordFinishActions = [];
    this.videoRecordDiscardActions = [this.restart];
}

configure(new Effect());

function setBearMask() {
    removeMask();
    Api.meshfxMsg("spawn", 0, 0, "bear_face.bsm2");
    Api.meshfxMsg("spawn", 1, 0, "bear_body_stand.bsm2");
    Api.meshfxMsg("spawn", 2, 0, "bear_hair.bsm2");
    Api.meshfxMsg("spawn", 3, 0, "bear.bsm2");
    state = 1;    
}

function setWolfMask() {
    removeMask();
    Api.meshfxMsg("spawn", 0, 0, "wolf_body.bsm2");
    state = 2;
}

function removeMask() {
    if(state === 1) {
        Api.meshfxMsg("del", 0);
        Api.meshfxMsg("del", 1);
        Api.meshfxMsg("del", 2);
        Api.meshfxMsg("del", 3);
    } else if(state === 2){
        Api.meshfxMsg("del", 0);
    }
    state = 0;
}

function setNarratorMask() {
    removeMask();
}

function getHeadRotation() {
    const mv = Api.modelview();
    const rot = (-mv[2]) * settings.global.headRotSens;

    if (rot <= -0.33333) return -1;     // left
	if (rot <= 0.33333) return 0;       // center
	else return 1;                      // right
}
